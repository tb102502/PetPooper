--Made by xXConnor_StarXx

--(Coming soon)For Building tips and scripting Subscibe to my youtube channel https://www.youtube.com/channel/UCNm5F0aprgERrTHaI464lIg

--Delete this script if you want Have a good day

























--PS Check out my other models :D they might come in useful